package za.ac.cput.company;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 * Name:            Robyn
 * Surname:         Southgate
 * Student Number:  217243576
 * Assignment 3
 */

public class SuppliersFigure2 {
    ObjectInputStream obj;
    ArrayList<Supplier> suppliersValue;
    ArrayList<Customer> customers;
    
    public SuppliersFigure2 (){
        suppliersValue = new ArrayList();
    }
  
    public void Lists() throws FileNotFoundException, IOException {
        try{
            obj = new ObjectInputStream(new FileInputStream("stakeholder.ser"));
            while(true){
                suppliersValue.add((Supplier)obj.readObject());
            } 
        }
        catch(EOFException e){
           System.out.println("File closed.");
        }
        catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
          catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
          }
        SupplierToTextFile();
    }
    
    public void displaySuppliers(){
        for(Supplier s: suppliersValue){
            System.out.println(s);
        }
    }
    
    public void SupplierToTextFile(){
        try{
    PrintWriter writer = new PrintWriter(new FileWriter("supplierOutFile.txt"));
    System.out.println("==================== SUPPLIERS ====================\n");
    System.out.println("ID   	Name      Prod Type	Description    \n");
    System.out.println("===================================================\n");
        for(int i = 0; i < suppliersValue.size() - 1; i++){
            for(int s = i + 1; s < suppliersValue.size(); s++){
                if(suppliersValue.get(i).getName().compareTo(customers.get(s).getFirstName()) > 0){
                   Supplier sup = suppliersValue.get(i);
                   suppliersValue.set(i, suppliersValue.get(s)); 
                   suppliersValue.set(s, sup);
            }
        }
    }
            for(Supplier s: suppliersValue){
                if( s.getName().length() < 8)
                    System.out.println(s.getStHolderId()+ "\t"+ s.getName()+ "\t\t\t" +s.getProductType()+ "\t\t\t" + s.getProductDescription()+"\n");
                else
                    System.out.println(s.getStHolderId()+ "\t"+ s.getName()+ "\t\t" + s.getProductType()+ "\t\t" + s.getProductDescription()+"\n");
            }
            writer.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    public static void main(String[] args) throws IOException {
    new SuppliersFigure2().Lists();
    }  
}
    

