package za.ac.cput.company;

import java.io.IOException;

/**
 * Name:            Robyn
 * Surname:         Southgate
 * Student Number:  217243576
 * Assignment 3
 */

public class ReadCustomerFigure1 {
    public static void main(String[] args) throws IOException{
        CustomerFigure1 cf1 = new CustomerFigure1();
        cf1.writeCustomerToTextFile();
    }
}
