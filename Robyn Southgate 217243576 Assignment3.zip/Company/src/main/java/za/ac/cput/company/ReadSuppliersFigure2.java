package za.ac.cput.company;

/**
 * Name:            Robyn
 * Surname:         Southgate
 * Student Number:  217243576
 * Assignment 3
 */

public class ReadSuppliersFigure2 {
    public static void main(String[] args){
        SuppliersFigure2 sf2 = new SuppliersFigure2();
        sf2.SupplierToTextFile();     
    }
}
